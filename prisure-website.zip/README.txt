PRISURE website
Open index.html in a browser, or upload the whole folder to any web host.
Edit menu prices: js/script.js (MENU object). Instagram URL: js/script.js (IG constant).
Fonts load from Google Fonts (internet needed for them; fallbacks are built in).
