const IMG={
 "bonfire": "images/bonfire.jpeg",
 "cof": "images/cof.jpeg",
 "coffee": "images/coffee.jpeg",
 "hike": "images/hike.jpeg",
 "menu": "images/menu.jpeg",
 "mountain": "images/mountain.jpeg",
 "mv_1": "images/mv_1.jpeg",
 "mv_2": "images/mv_2.jpeg",
 "mv_3": "images/mv_3.jpeg",
 "mv_4": "images/mv_4.jpeg",
 "mv_5": "images/mv_5.jpeg",
 "nature_trails": "images/nature_trails.jpeg",
 "p_logo": "images/p_logo.jpeg",
 "photograpy_spot": "images/photograpy_spot.jpeg",
 "services": "images/services.jpeg",
 "travellers_meet_up": "images/travellers_meet_up.jpeg"
};
const MENU={"Coffee & Hot Drinks":[["Espresso",120],["Cappuccino",160],["Latte",170],["Mocha",190],["Hot Chocolate",180],["PRISURE Signature Coffee",220]],
"Cold Drinks":[["Iced Latte",190],["Cold Coffee",180],["Iced Mocha",210],["Lemon Cooler",120],["Seasonal Coolers",160]],
"Breakfast & Brunch":[["Pancakes",240],["French Toast",220],["Avocado Toast",260],["Breakfast Bowl",250],["Croissants",150]],
"Comfort Plates":[["Pasta",280],["Sandwiches",200],["Burgers",260],["Fries",150],["Rice Bowls",240]],
"Desserts":[["Chocolate Cake",180],["Cheesecake",210],["Brownie",160],["Waffles",200],["Ice Cream",140]]};
const $=s=>document.querySelector(s),h=(id,x)=>$(id).innerHTML=x;
document.querySelectorAll('[data-i]').forEach(i=>i.src=IMG[i.dataset.i]);
const IG="https://www.instagram.com/prisure._?stkn=MXZmdGEwYTh5dTUwMg==";
const flip=(front,back,cls="")=>`<div class="flip ${cls}" tabindex="0"><div class="fi">${front}<div class="fb">${back}</div></div></div>`;
h('#four',[["STAY","Comfortable spaces surrounded by mountains."],["SIP","Coffee, food and slow café moments."],["EXPLORE","Discover Manali and its surroundings."],["CONNECT","Meet people, share stories and create memories."]].map(a=>`<div class="tile"><h3>${a[0]}</h3><p>${a[1]}</p></div>`).join(''));
h('#worlds',[["THE HOTEL","Stay among the mountains.","EXPLORE THE HOTEL","#hotel","mv_1"],["THE CAFÉ","Slow mornings taste better here.","EXPLORE THE CAFÉ","#cafe","coffee"]].map(a=>`<div class="world rv" onclick="location.hash='${a[3]}'"><img data-i="${a[4]}" alt=""><div><h2>${a[0]}</h2><p>${a[1]}</p><a class="btn gold sm" href="${a[3]}">${a[2]}</a></div></div>`).join(''));
const S=[["🏔️","MOUNTAIN VIEW ROOMS","Comfortable rooms with scenic Himalayan views."],["📶","HIGH-SPEED WI-FI","Stay connected when you need to."],["🛎️","ROOM SERVICE","Enjoy food and refreshments from the comfort of your room."],["🔥","BONFIRE EVENINGS","Relax under the mountain sky."],["🌲","NATURE EXPERIENCES","Explore the natural beauty around Manali."],["📷","PHOTOGRAPHY SPOTS","Scenic locations for capturing memories."],["📖","RELAXATION SPACES","Quiet spaces to read, work or simply unwind."],["☕","IN-HOUSE CAFÉ","Easy access to the PRISURE café."]];
h('#svc',S.map(s=>flip(`<div class="ff ico"><b>${s[0]}</b><h3>${s[1]}</h3><span class="hint">TAP TO FLIP</span></div>`,`<h3>${s[1]}</h3><p>${s[2]}</p>`)).join(''));
const R=[["Mountain View Room","mv_1","Wake up to panoramic mountain views.",["Sunrise-facing balcony","King bed","Wi-Fi"],2500],["Cozy Room","mv_4","A warm timber-ceiling nook made for slow mornings.",["Wood interiors","Reading corner","Wi-Fi"],2000],["Traveller Room","mv_2","Simple, bright and comfortable for solo wanderers.",["Valley window","Fresh linen","Wi-Fi"],2200],["Premium Suite","mv_3","Floor-to-ceiling views with space to work and unwind.",["Desk & lounge","Room service","Wi-Fi"],3000]];
const fm=n=>'₹'+n.toLocaleString('en-IN');
h('#rm',R.map((r,i)=>flip(`<div class="ff im"><img data-i="${r[1]}" alt="${r[0]}"><h3>${r[0]}</h3><span class="hint">FROM ${fm(r[4])} / NIGHT · TAP TO FLIP</span></div>`,`<h3>${r[0]}</h3><p>${r[2]}</p><ul>${r[3].map(a=>`<li>${a}</li>`).join('')}</ul><div class="pr">${fm(r[4])} <small>/ night</small></div><div class="row"><button class="btn o sm" style="color:var(--g)" onclick="event.stopPropagation();lb('${r[1]}')">VIEW ROOM</button><a class="btn sm" href="#book" onclick="event.stopPropagation();$('#rt').selectedIndex=${i}">BOOK NOW</a></div>`,'tall')).join(''));
h('#rt',R.map(r=>`<option>${r[0]} — ${fm(r[4])}</option>`).join(''));
h('#of',[["WEEKEND ESCAPE","Stay 2 nights and receive 10% OFF."],["MOUNTAIN MORNING","Complimentary breakfast with selected room bookings."],["STAY + SIP","Book a hotel stay and receive a café voucher."],["EARLY BIRD","Book in advance and receive a special discounted rate."]].map(o=>`<div class="tile off"><h3>${o[0]}</h3><p>${o[1]}</p><a class="btn sm" href="#book">BOOK OFFER</a></div>`).join(''));
h('#sp',[["SIGNATURE COFFEE","cof","Unique PRISURE drinks created for mountain mornings.",""],["MOUNTAIN VIEWS","mountain","Enjoy your food with beautiful surroundings.",""],["COMFORT FOOD","menu","Simple, satisfying food made for slow moments.","object-position:85% 48%"],["SLOW CAFÉ CULTURE","coffee","A space where nobody has to rush.","object-position:50% 75%"]].map(s=>flip(`<div class="ff im"><img data-i="${s[1]}" style="${s[3]}" alt=""><h3>${s[0]}</h3><span class="hint">TAP TO FLIP</span></div>`,`<h3>${s[0]}</h3><p>${s[2]}</p><a class="btn sm" href="#menu" onclick="event.stopPropagation()">SEE THE MENU</a>`,'tall')).join(''));
const cats=Object.keys(MENU);
h('#tabs',cats.map((c,i)=>`<button class="tab" data-c="${c}">${c.toUpperCase()}</button>`).join(''));
function showMenu(c){document.querySelectorAll('.tab').forEach(t=>t.classList.toggle('a',t.dataset.c==c));h('#mn',MENU[c].map(m=>`<div class="mi"><span>${m[0]}</span><i></i><b>₹${m[1]}</b></div>`).join(''))}
document.querySelectorAll('.tab').forEach(t=>t.onclick=()=>showMenu(t.dataset.c));showMenu(cats[0]);
const E=[["BONFIRE EVENINGS","bonfire","Warm fires, quiet stories and a sky full of stars."],["MOUNTAIN HIKES","hike","Guided walks through open meadows and ridgelines."],["PHOTOGRAPHY SPOTS","photograpy_spot","Misty valleys and golden-hour viewpoints."],["TRAVELLER MEET-UPS","travellers_meet_up","Share the summit sunset with new friends."],["NATURE TRAILS","nature_trails","Riverside paths and shaded bridges to wander."]];
h('#ex',E.map(e=>flip(`<div class="ff im"><img data-i="${e[1]}" alt="${e[0]}"><h3>${e[0]}</h3><span class="hint">TAP TO FLIP</span></div>`,`<h3>${e[0]}</h3><p>${e[2]}</p><a class="btn sm" href="#book" onclick="event.stopPropagation()">PLAN IT</a>`,'tall')).join(''));
h('#tm',[["Woke up to peaks turning gold outside our window. Slowest, best weekend.","Aanya, Mumbai"],["The PRISURE Cloud alone is worth the drive. Stayed all afternoon.","Kabir, Delhi"],["Bonfire night felt like meeting friends I hadn't made yet.","Meera, Pune"]].map(t=>`<div class="tile"><div class="quote">“${t[0]}”</div><p class="pop" style="color:var(--gold);font-weight:700">★★★★★ · ${t[1]}</p></div>`).join(''));
h('#ig',[["mv_1","MOUNTAIN VIEWS"],["coffee","COFFEE"],["mv_3","ROOMS"],["cof","CAFÉ"],["travellers_meet_up","TRAVELLERS"],["bonfire","EXPERIENCES"],["mountain","MOUNTAIN VIEWS"],["hike","EXPERIENCES"]].map(g=>`<div><img data-i="${g[0]}" alt=""><span>${g[1]}</span></div>`).join(''));
const cafeForm=p=>`<form id="${p}"><h3>RESERVE A CAFÉ TABLE</h3><div class="two"><label>Name<input required></label><label>Phone<input type="tel" required></label></div><div class="two"><label>Email<input type="email" required></label><label>Guests<input type="number" min="1" max="12" value="2"></label></div><div class="two"><label>Date<input type="date" required></label><label>Time<input type="time" required></label></div><label>Special requests<textarea rows="2"></textarea></label><button class="btn">RESERVE TABLE</button><div class="ok">${p=='cf1f'?'Your PRISURE table is waiting.':'Your PRISURE experience is one step closer.'}</div></form>`;
h('#cf1',cafeForm('cf1f'));h('#cf2',cafeForm('cf2f'));
document.querySelectorAll('[data-i]').forEach(i=>i.src=IMG[i.dataset.i]);
document.querySelectorAll('.igl,#igl').forEach(a=>a.href=IG);
/* interactions */
document.addEventListener('click',e=>{const f=e.target.closest('.flip');if(f&&!e.target.closest('a,button'))f.classList.toggle('on')});
document.addEventListener('keydown',e=>{if(e.key=='Enter'&&e.target.classList.contains('flip'))e.target.classList.toggle('on')});
document.addEventListener('submit',e=>{e.preventDefault();const f=e.target;const ok=f.id=='hf'?$('#hok'):f.querySelector('.ok');ok.classList.add('s');$('#av')&&f.id=='hf'&&$('#av').classList.remove('s');f.querySelectorAll('.btn').forEach(b=>b.style.display='none')});
function lb(k){$('#lbi').src=IMG[k];$('#lb').classList.add('o')}
$('#bg').onclick=()=>$('#ul').classList.toggle('o');$('#ul').onclick=()=>$('#ul').classList.remove('o');
const today=new Date().toISOString().slice(0,10);['#ci','#co'].forEach(s=>$(s).min=today);
$('#chk').onclick=()=>{const a=$('#ci').value,b=$('#co').value;if(!a||!b||b<=a){h('#av','Please choose a check-out date after check-in.');$('#av').classList.add('s');return}
const n=(new Date(b)-new Date(a))/864e5,r=R[$('#rt').selectedIndex];let t=n*r[4],off=n>=2?' (incl. 10% Weekend Escape)':'';if(n>=2)t*=.9;
h('#av',`Available: ${r[0]}, ${n} night${n>1?'s':''} · ${fm(Math.round(t))}${off}`);$('#av').classList.add('s');$('#bn').style.display='block'};
document.querySelectorAll('#st span').forEach((s,i,all)=>s.onclick=()=>all.forEach((x,j)=>x.classList.toggle('on',j<=i)));
document.querySelectorAll('[data-split]').forEach(el=>{el.innerHTML=el.textContent.split(' ').map((w,i)=>`<span class="w" style="transition-delay:${i*.12}s">${w}</span>`).join(' ');el.classList.add('rv')});
const io=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting){e.target.classList.add('in');io.unobserve(e.target)}}),{threshold:.15});
document.querySelectorAll('.rv,.grid>.flip,.grid>.tile').forEach(el=>{el.classList.add('rv');io.observe(el)});
const hb=$('#hbg'),pb=document.querySelector('.pbg'),nav=$('#nav');
addEventListener('scroll',()=>{const y=scrollY;nav.classList.toggle('s',y>20);hb.style.transform=`translateY(${y*.25}px) scale(1.05)`;const c=pb.parentElement.getBoundingClientRect();pb.style.transform=`translateY(${(c.top)*-.1}px)`},{passive:true});
